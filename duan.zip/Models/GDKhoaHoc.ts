export function GhiDanh(){
    this.MaKhoaKhoaHoc = '';
    this.TaiKhoan = '';
}