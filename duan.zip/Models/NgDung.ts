export function NguoiDung (){
    this.TaiKhoan = '';
    this.MatKhau = '';
    this.HoTen = '';
    this.Email = '';
    this.SoDT = '';
    this.MaLoaiNguoiDung = '';
    this.TenLoaiNguoiDung = '';
}