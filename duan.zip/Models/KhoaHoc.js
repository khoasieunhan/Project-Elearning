"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function KhoaHoc() {
    this.MaKhoaHoc = '';
    this.TenKhoaHoc = '';
    this.MoTa = '';
    this.HinhAnh = '';
    this.LuotXem = '';
    this.NguoiTao = '';
}
exports.KhoaHoc = KhoaHoc;
