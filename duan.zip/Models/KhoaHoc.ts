export function KhoaHoc(){
    this.MaKhoaHoc='';
    this.TenKhoaHoc ='';
    this.MoTa = '';
    this.HinhAnh = '';
    this.LuotXem='';
    this.NguoiTao = '';
}