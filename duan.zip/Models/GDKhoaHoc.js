"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function GhiDanh() {
    this.MaKhoaKhoaHoc = '';
    this.TaiKhoan = '';
}
exports.GhiDanh = GhiDanh;
